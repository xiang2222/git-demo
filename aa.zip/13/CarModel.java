import java.io.*;
import java.net.URL;
import java.net.URI;
import javax.swing.*;
import java.util.*;

public class CarModel implements Observable{
    private Vector<Observer> observersList;
    private ImageIcon imgIcon;
    private URL url;
    private String[] carNameList;
	private String carSelected;
	private String bitPrice;
	private double[ ] currentBitPrices = new double[4];
	private double[ ] preBitPrices = new double[4];
    private boolean isBitBtnClicked = false;
    private boolean isSearchBtnClicked = false;
    static final String CARFILES = "CarFiles/";
    static final String CARIMAGES = "CarImages/";

    public CarModel(){
          observersList = new Vector<Observer>();
          carNameList=new String[200];
  	}
    public void setCarList(String[] cars){
		  carNameList = cars;
	}
    public String[] getCarList(){
	      return  carNameList;
    }
    public void setSelectedCar(String sCar){
          carSelected = sCar;
  	}
  	public String getSelectedCar(){
	      return carSelected;
  	}
  	public void setBitPrice(String bPrice){
		  bitPrice = bPrice;
		  if(this.isNumber(bitPrice))
		  {
			  if(this.validateAuctionPrice(carSelected, bitPrice))
			  {;}
			  else
				  bitPrice="illegal bit price";
		  }
		  else
			  bitPrice="illegal bit price";
	}
	public String getBitPrice(){
		  return bitPrice;
	}
	public void setFileUrl(){
	      try{
		        String fileURLStr = CARFILES + carSelected+ ".html";
		        URI uri = (new File(fileURLStr)).toURI();
		        url = uri.toURL();
		  }
		  catch (IOException e){
		        e.printStackTrace();
		 }
	}
	public URL getCarFileURL(){
		 return url;
	}
    public void setupImageIcon(){
	     String iconStr = CARIMAGES + carSelected+".jpg";
         imgIcon = createImageIcon(iconStr);
	}
    public ImageIcon getImageIcon(){
	     return imgIcon;
	}
    public void setBitBtnClickInfo(boolean opt){
	     isBitBtnClicked = opt;
	}
    
    public boolean isNumber(String bitprice)
    {
    	String str="[0-9]+";
    	if(bitprice.matches(str))
    		return true;
    	return false;
    }
    
    public boolean validateAuctionPrice(String car,String bitprice)
    {
    	if(car.equals("Honda Accord-2005"))
    	{
    		currentBitPrices[0]=Integer.parseInt(bitprice);
    		if(preBitPrices[0]<currentBitPrices[0])
    		{
    			preBitPrices[0]=currentBitPrices[0];
    			return true;
    		}
    	}
    	else if(car.equals("Honda Civic-2006"))
    	{
    		currentBitPrices[1]=Integer.parseInt(bitprice);
    		if(preBitPrices[1]<currentBitPrices[1])
    		{
    			preBitPrices[1]=currentBitPrices[1];
    			return true;
    		}
    	}
    	else if(car.equals("Toyota Camry-2003"))
    	{
    		currentBitPrices[2]=Integer.parseInt(bitprice);
    		if(preBitPrices[2]<currentBitPrices[2])
    		{
    			preBitPrices[2]=currentBitPrices[2];
    			return true;
    		}
    	}
    	else if(car.equals("Toyota Corolla-2002"))
    	{
    		currentBitPrices[3]=Integer.parseInt(bitprice);
    		if(preBitPrices[3]<currentBitPrices[3])
    		{
    			preBitPrices[3]=currentBitPrices[3];
    			return true;
    		}
    	}
    	return false;
    }
    
	public boolean isBitBtnClicked(){
	     return isBitBtnClicked;
	}
    public void setSearchBtnClickInfo(boolean opt){
	     isSearchBtnClicked = opt;
	}
	public boolean isSearchBtnClicked(){
	     return isSearchBtnClicked;
	}
    public void register(Observer obs){
	     observersList.addElement(obs);
    }
    public void notifyObservers() {
         for (int i = 0; i < observersList.size(); i++) {
              Observer observer = (Observer) observersList.get(i);
			  observer.update(this);
         }
    }
    protected ImageIcon createImageIcon(String path){
         java.net.URL imgURL = getClass().getResource(path);
         if (imgURL != null) {
               return new ImageIcon(imgURL);
         }
         else {
              System.err.println("Couldn't find file: " + path);
              return null;
         }
   }
}