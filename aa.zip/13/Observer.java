




public interface Observer {
     public void update(Observable subject);
}
